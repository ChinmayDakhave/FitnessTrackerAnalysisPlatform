// Recommendations page JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize recommendation system
    initializeRecommendations();
    
    // Add filter form enhancements
    enhanceFilterForm();
    
    // Add recommendation card interactions
    addCardInteractions();
    
    // Initialize tooltips for recommendation scores
    initializeTooltips();
});

function initializeRecommendations() {
    // Add loading state to filter form
    const filterForm = document.querySelector('form');
    if (filterForm) {
        filterForm.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Filtering...';
            submitBtn.disabled = true;
            
            // Re-enable after a short delay (in case of errors)
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        });
    }
    
    // Add real-time price range validation
    const minPriceInput = document.getElementById('min_price');
    const maxPriceInput = document.getElementById('max_price');
    
    if (minPriceInput && maxPriceInput) {
        minPriceInput.addEventListener('input', function() {
            const minValue = parseFloat(this.value);
            const maxValue = parseFloat(maxPriceInput.value);
            
            if (minValue > maxValue) {
                maxPriceInput.value = minValue;
            }
        });
        
        maxPriceInput.addEventListener('input', function() {
            const maxValue = parseFloat(this.value);
            const minValue = parseFloat(minPriceInput.value);
            
            if (maxValue < minValue) {
                minPriceInput.value = maxValue;
            }
        });
    }
}

function enhanceFilterForm() {
    // Add dynamic filter indicators
    const filterInputs = document.querySelectorAll('select, input[type="number"]');
    
    filterInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateFilterIndicators();
        });
    });
    
    // Add clear individual filter buttons
    const filterGroups = document.querySelectorAll('.col-md-3');
    filterGroups.forEach(group => {
        const input = group.querySelector('select, input');
        if (input && input.value && input.value !== '') {
            addClearButton(group, input);
        }
    });
}

function updateFilterIndicators() {
    const activeFilters = [];
    
    // Check brand filter
    const brandSelect = document.getElementById('brand');
    if (brandSelect && brandSelect.value) {
        activeFilters.push(`Brand: ${brandSelect.value}`);
    }
    
    // Check price filters
    const minPrice = document.getElementById('min_price');
    const maxPrice = document.getElementById('max_price');
    if (minPrice && maxPrice) {
        const minVal = parseFloat(minPrice.value);
        const maxVal = parseFloat(maxPrice.value);
        if (minVal > minPrice.min || maxVal < maxPrice.max) {
            activeFilters.push(`Price: $${minVal}-$${maxVal}`);
        }
    }
    
    // Check rating filter
    const ratingSelect = document.getElementById('min_rating');
    if (ratingSelect && ratingSelect.value) {
        activeFilters.push(`Rating: ${ratingSelect.value}+`);
    }
    
    // Check battery filter
    const batteryInput = document.getElementById('min_battery');
    if (batteryInput && batteryInput.value > batteryInput.min) {
        activeFilters.push(`Battery: ${batteryInput.value}+ days`);
    }
    
    // Update filter indicator
    let filterIndicator = document.querySelector('.filter-indicator');
    if (activeFilters.length > 0) {
        if (!filterIndicator) {
            filterIndicator = document.createElement('div');
            filterIndicator.className = 'filter-indicator alert alert-info mt-2';
            document.querySelector('.card-body').appendChild(filterIndicator);
        }
        filterIndicator.innerHTML = `
            <i class="fas fa-filter me-2"></i>
            Active filters: ${activeFilters.join(', ')}
        `;
    } else if (filterIndicator) {
        filterIndicator.remove();
    }
}

function addClearButton(group, input) {
    const clearBtn = document.createElement('button');
    clearBtn.type = 'button';
    clearBtn.className = 'btn btn-sm btn-outline-secondary ms-2';
    clearBtn.innerHTML = '<i class="fas fa-times"></i>';
    clearBtn.title = 'Clear this filter';
    
    clearBtn.addEventListener('click', function() {
        if (input.tagName === 'SELECT') {
            input.selectedIndex = 0;
        } else {
            input.value = input.defaultValue;
        }
        updateFilterIndicators();
    });
    
    group.querySelector('.d-flex, .mb-3').appendChild(clearBtn);
}

function addCardInteractions() {
    // Add click-to-expand functionality
    const recommendationCards = document.querySelectorAll('.recommendation-card');
    
    recommendationCards.forEach(card => {
        // Add hover effects
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        });
        
        // Add click functionality for detailed view
        card.addEventListener('click', function() {
            showProductDetails(this);
        });
        
        // Add favorite functionality
        addFavoriteButton(card);
    });
    
    // Add sorting functionality
    addSortingControls();
}

function showProductDetails(card) {
    const productName = card.querySelector('.card-title').textContent;
    const productBrand = card.querySelector('.text-muted').textContent;
    const productRating = card.querySelector('.text-warning').textContent;
    const productPrice = card.querySelector('.text-success').textContent;
    
    // Create modal or expand card
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${productName}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Product Information</h6>
                            <p><strong>Brand:</strong> ${productBrand}</p>
                            <p><strong>Rating:</strong> ${productRating}</p>
                            <p><strong>Price:</strong> ${productPrice}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Features</h6>
                            <div class="features-detail">
                                ${card.querySelector('.features').innerHTML}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Add to Favorites</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    
    // Clean up modal after hiding
    modal.addEventListener('hidden.bs.modal', function() {
        document.body.removeChild(modal);
    });
}

function addFavoriteButton(card) {
    const favoriteBtn = document.createElement('button');
    favoriteBtn.className = 'btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2';
    favoriteBtn.innerHTML = '<i class="far fa-heart"></i>';
    favoriteBtn.title = 'Add to favorites';
    
    favoriteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        
        if (this.querySelector('i').classList.contains('far')) {
            this.querySelector('i').classList.replace('far', 'fas');
            this.classList.replace('btn-outline-danger', 'btn-danger');
            this.title = 'Remove from favorites';
            
            // Show success message
            showNotification('Added to favorites!', 'success');
        } else {
            this.querySelector('i').classList.replace('fas', 'far');
            this.classList.replace('btn-danger', 'btn-outline-danger');
            this.title = 'Add to favorites';
            
            showNotification('Removed from favorites!', 'info');
        }
    });
    
    card.style.position = 'relative';
    card.appendChild(favoriteBtn);
}

function addSortingControls() {
    const cardHeader = document.querySelector('.card-header');
    if (cardHeader) {
        const sortingDropdown = document.createElement('div');
        sortingDropdown.className = 'dropdown';
        sortingDropdown.innerHTML = `
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-sort me-1"></i>Sort By
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#" data-sort="score">Recommendation Score</a></li>
                <li><a class="dropdown-item" href="#" data-sort="price-low">Price: Low to High</a></li>
                <li><a class="dropdown-item" href="#" data-sort="price-high">Price: High to Low</a></li>
                <li><a class="dropdown-item" href="#" data-sort="rating">Rating</a></li>
                <li><a class="dropdown-item" href="#" data-sort="battery">Battery Life</a></li>
            </ul>
        `;
        
        cardHeader.appendChild(sortingDropdown);
        
        // Add sorting functionality
        sortingDropdown.addEventListener('click', function(e) {
            if (e.target.matches('.dropdown-item')) {
                e.preventDefault();
                const sortType = e.target.dataset.sort;
                sortRecommendations(sortType);
            }
        });
    }
}

function sortRecommendations(sortType) {
    const container = document.querySelector('.row');
    const cards = Array.from(container.querySelectorAll('.recommendation-card')).map(card => card.closest('.col-md-6'));
    
    cards.sort((a, b) => {
        const cardA = a.querySelector('.recommendation-card');
        const cardB = b.querySelector('.recommendation-card');
        
        switch (sortType) {
            case 'score':
                const scoreA = parseFloat(cardA.querySelector('.badge').textContent);
                const scoreB = parseFloat(cardB.querySelector('.badge').textContent);
                return scoreB - scoreA;
            
            case 'price-low':
                const priceA = parseFloat(cardA.querySelector('.text-success').textContent.replace('$', ''));
                const priceB = parseFloat(cardB.querySelector('.text-success').textContent.replace('$', ''));
                return priceA - priceB;
            
            case 'price-high':
                const priceA2 = parseFloat(cardA.querySelector('.text-success').textContent.replace('$', ''));
                const priceB2 = parseFloat(cardB.querySelector('.text-success').textContent.replace('$', ''));
                return priceB2 - priceA2;
            
            case 'rating':
                const ratingA = parseFloat(cardA.querySelector('.text-warning').textContent.split(' ')[1]);
                const ratingB = parseFloat(cardB.querySelector('.text-warning').textContent.split(' ')[1]);
                return ratingB - ratingA;
            
            case 'battery':
                const batteryA = parseFloat(cardA.querySelector('.small').textContent.split(' ')[1]);
                const batteryB = parseFloat(cardB.querySelector('.small').textContent.split(' ')[1]);
                return batteryB - batteryA;
            
            default:
                return 0;
        }
    });
    
    // Re-append sorted cards
    cards.forEach(card => container.appendChild(card));
    
    // Show sorting notification
    showNotification(`Sorted by ${sortType.replace('-', ' ')}`, 'info');
}

function initializeTooltips() {
    // Add tooltips to recommendation scores
    const scoreBadges = document.querySelectorAll('.badge');
    scoreBadges.forEach(badge => {
        badge.setAttribute('data-bs-toggle', 'tooltip');
        badge.setAttribute('data-bs-placement', 'top');
        badge.setAttribute('title', 'Recommendation Score (0-5)');
    });
    
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Add keyboard navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        // Close any open modals
        const openModals = document.querySelectorAll('.modal.show');
        openModals.forEach(modal => {
            bootstrap.Modal.getInstance(modal).hide();
        });
    }
});

// Add accessibility improvements
document.addEventListener('DOMContentLoaded', function() {
    // Add ARIA labels
    const cards = document.querySelectorAll('.recommendation-card');
    cards.forEach((card, index) => {
        card.setAttribute('role', 'button');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-label', `Product recommendation ${index + 1}`);
        
        // Add keyboard navigation
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
});
