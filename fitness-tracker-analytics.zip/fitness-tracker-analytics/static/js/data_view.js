// Data View page JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize DataTable
    initializeDataTable();
    
    // Add export functionality
    setupExportButtons();
    
    // Add column visibility controls
    addColumnVisibilityControls();
    
    // Add advanced filtering
    setupAdvancedFiltering();
    
    // Add responsive features
    setupResponsiveFeatures();
});

function initializeDataTable() {
    // Check if DataTable is already initialized
    if ($.fn.DataTable.isDataTable('#dataTable')) {
        $('#dataTable').DataTable().destroy();
    }
    
    // Initialize DataTable with comprehensive options
    const table = $('#dataTable').DataTable({
        // Basic configuration
        responsive: true,
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        order: [[1, 'asc']], // Sort by name initially
        
        // Search configuration
        search: {
            regex: true,
            smart: true
        },
        
        // Column configuration
        columnDefs: [
            {
                targets: '_all',
                className: 'text-center'
            },
            {
                targets: [0], // ID column
                width: '50px',
                searchable: false
            },
            {
                targets: [1, 2], // Name and Brand columns
                className: 'text-start'
            },
            {
                targets: [3], // Price column
                type: 'num',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return '₹' + parseFloat(data).toLocaleString('en-IN');
                    }
                    return data;
                }
            },
            {
                targets: [4], // Rating column
                type: 'num',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return '<span class="text-warning"><i class="fas fa-star"></i> ' + data + '</span>';
                    }
                    return data;
                }
            },
            {
                targets: [6], // Battery life column
                type: 'num',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return data + ' days';
                    }
                    return data;
                }
            },
            {
                targets: [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28], // Boolean columns
                render: function(data, type, row) {
                    if (type === 'display') {
                        return data ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>';
                    }
                    return data;
                }
            }
        ],
        
        // Language configuration
        language: {
            search: "Global Search:",
            searchPlaceholder: "Search across all columns...",
            lengthMenu: "Show _MENU_ entries per page",
            info: "Showing _START_ to _END_ of _TOTAL_ products",
            infoEmpty: "No products found",
            infoFiltered: "(filtered from _MAX_ total products)",
            emptyTable: "No fitness tracker data available",
            zeroRecords: "No matching products found"
        },
        
        // DOM configuration for Bootstrap integration
        dom: 
            "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
            "<'row'<'col-sm-12'B>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        
        // Styling
        className: 'table table-striped table-bordered table-hover',
        
        // Performance optimization
        deferRender: true,
        processing: true,
        
        // Callback functions
        initComplete: function(settings, json) {
            // Add individual column search
            addColumnSearch(this);
            
            // Add loading indicator
            $('#dataTable_processing').removeClass('d-none');
            
            // Initialize tooltips
            initializeTableTooltips();
            
            // Show table statistics
            updateTableStatistics();
        },
        
        drawCallback: function(settings) {
            // Re-initialize tooltips after each draw
            initializeTableTooltips();
            
            // Update row numbers
            updateRowNumbers();
            
            // Highlight search terms
            highlightSearchTerms();
        }
    });
    
    // Store table reference globally
    window.dataTable = table;
    
    // Add custom search functionality
    addCustomSearch(table);
    
    return table;
}

function addColumnSearch(table) {
    // Add individual column search inputs
    $('#dataTable thead tr').clone(true).appendTo('#dataTable thead');
    $('#dataTable thead tr:eq(1) th').each(function(i) {
        const title = $(this).text();
        
        // Skip certain columns from individual search
        if (i === 0 || title.includes('Action')) {
            $(this).html('');
            return;
        }
        
        // Create search input
        const searchInput = $('<input type="text" class="form-control form-control-sm" placeholder="Search ' + title + '..." />');
        
        searchInput.on('keyup change', function() {
            if (table.column(i).search() !== this.value) {
                table.column(i).search(this.value).draw();
            }
        });
        
        $(this).html(searchInput);
    });
}

function addCustomSearch(table) {
    // Add advanced search functionality
    const advancedSearchContainer = $('<div class="advanced-search-container mb-3"></div>');
    
    // Price range search
    const priceRangeHTML = `
        <div class="row mb-2">
            <div class="col-md-3">
                <label class="form-label">Price Range</label>
                <div class="input-group">
                    <span class="input-group-text">₹</span>
                    <input type="number" id="price-min" class="form-control" placeholder="Min" min="0">
                    <span class="input-group-text">-</span>
                    <span class="input-group-text">₹</span>
                    <input type="number" id="price-max" class="form-control" placeholder="Max" min="0">
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">Rating Range</label>
                <div class="input-group">
                    <input type="number" id="rating-min" class="form-control" placeholder="Min" min="1" max="5" step="0.1">
                    <span class="input-group-text">-</span>
                    <input type="number" id="rating-max" class="form-control" placeholder="Max" min="1" max="5" step="0.1">
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">Battery Life (days)</label>
                <div class="input-group">
                    <input type="number" id="battery-min" class="form-control" placeholder="Min" min="0">
                    <span class="input-group-text">-</span>
                    <input type="number" id="battery-max" class="form-control" placeholder="Max" min="0">
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">Actions</label>
                <div>
                    <button type="button" id="apply-advanced-search" class="btn btn-primary btn-sm">Apply</button>
                    <button type="button" id="clear-advanced-search" class="btn btn-outline-secondary btn-sm ms-2">Clear</button>
                </div>
            </div>
        </div>
    `;
    
    advancedSearchContainer.html(priceRangeHTML);
    $('#dataTable_wrapper').prepend(advancedSearchContainer);
    
    // Add event listeners for advanced search
    $('#apply-advanced-search').on('click', function() {
        applyAdvancedSearch(table);
    });
    
    $('#clear-advanced-search').on('click', function() {
        clearAdvancedSearch(table);
    });
}

function applyAdvancedSearch(table) {
    // Custom search function for advanced filtering
    $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
        const priceMin = parseFloat($('#price-min').val()) || 0;
        const priceMax = parseFloat($('#price-max').val()) || 999999;
        const ratingMin = parseFloat($('#rating-min').val()) || 0;
        const ratingMax = parseFloat($('#rating-max').val()) || 5;
        const batteryMin = parseFloat($('#battery-min').val()) || 0;
        const batteryMax = parseFloat($('#battery-max').val()) || 999;
        
        // Extract numeric values from formatted data
        const price = parseFloat(data[3].replace('₹', '').replace(/,/g, '')) || 0;
        const rating = parseFloat(data[4]) || 0;
        const battery = parseFloat(data[6]) || 0;
        
        // Check if row matches all criteria
        return (price >= priceMin && price <= priceMax) &&
               (rating >= ratingMin && rating <= ratingMax) &&
               (battery >= batteryMin && battery <= batteryMax);
    });
    
    table.draw();
    
    // Show notification
    showNotification('Advanced search applied successfully!', 'success');
}

function clearAdvancedSearch(table) {
    // Clear all advanced search inputs
    $('#price-min, #price-max, #rating-min, #rating-max, #battery-min, #battery-max').val('');
    
    // Remove custom search functions
    $.fn.dataTable.ext.search = [];
    
    table.draw();
    
    showNotification('Advanced search cleared!', 'info');
}

function setupExportButtons() {
    // Add export buttons to the page
    const exportButtonsHTML = `
        <div class="export-buttons mb-3">
            <button type="button" id="export-visible" class="btn btn-outline-success btn-sm me-2">
                <i class="fas fa-file-excel me-1"></i>Export Visible Data
            </button>
            <button type="button" id="export-selected" class="btn btn-outline-info btn-sm me-2">
                <i class="fas fa-file-csv me-1"></i>Export Selected Rows
            </button>
            <button type="button" id="print-table" class="btn btn-outline-dark btn-sm">
                <i class="fas fa-print me-1"></i>Print Table
            </button>
        </div>
    `;
    
    $('#dataTable_wrapper').prepend(exportButtonsHTML);
    
    // Add event listeners
    $('#export-visible').on('click', function() {
        exportVisibleData();
    });
    
    $('#export-selected').on('click', function() {
        exportSelectedRows();
    });
    
    $('#print-table').on('click', function() {
        printTable();
    });
}

function exportVisibleData() {
    const table = window.dataTable;
    const data = table.rows({search: 'applied'}).data().toArray();
    
    // Convert to CSV
    const headers = table.columns().header().toArray().map(th => $(th).text());
    const csvContent = [headers.join(',')];
    
    data.forEach(row => {
        const cleanRow = row.map(cell => {
            // Clean HTML tags and escape quotes
            const cleanCell = $(cell).text() || cell;
            return '"' + cleanCell.replace(/"/g, '""') + '"';
        });
        csvContent.push(cleanRow.join(','));
    });
    
    // Download CSV
    const csvData = csvContent.join('\n');
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'fitness_trackers_filtered.csv';
    link.click();
    
    showNotification('Visible data exported successfully!', 'success');
}

function exportSelectedRows() {
    const table = window.dataTable;
    const selectedRows = table.rows('.selected').data().toArray();
    
    if (selectedRows.length === 0) {
        showNotification('No rows selected. Click on rows to select them first.', 'warning');
        return;
    }
    
    // Convert to CSV (similar to exportVisibleData)
    const headers = table.columns().header().toArray().map(th => $(th).text());
    const csvContent = [headers.join(',')];
    
    selectedRows.forEach(row => {
        const cleanRow = row.map(cell => {
            const cleanCell = $(cell).text() || cell;
            return '"' + cleanCell.replace(/"/g, '""') + '"';
        });
        csvContent.push(cleanRow.join(','));
    });
    
    const csvData = csvContent.join('\n');
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'fitness_trackers_selected.csv';
    link.click();
    
    showNotification(`${selectedRows.length} selected rows exported successfully!`, 'success');
}

function printTable() {
    const table = window.dataTable;
    const printWindow = window.open('', '_blank');
    
    // Get visible data
    const data = table.rows({search: 'applied'}).data().toArray();
    const headers = table.columns().header().toArray().map(th => $(th).text());
    
    // Create print HTML
    const printHTML = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Fitness Tracker Data - ${new Date().toLocaleDateString()}</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                table { width: 100%; border-collapse: collapse; font-size: 12px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f8f9fa; font-weight: bold; }
                .text-center { text-align: center; }
                .badge { padding: 2px 6px; border-radius: 3px; font-size: 10px; }
                .bg-success { background-color: #d4edda; }
                .bg-secondary { background-color: #e2e3e5; }
                @media print { body { margin: 0; } }
            </style>
        </head>
        <body>
            <h1>Fitness Tracker Analytics - Data Export</h1>
            <p>Generated on: ${new Date().toLocaleString()}</p>
            <p>Total Records: ${data.length}</p>
            <table>
                <thead>
                    <tr>${headers.map(header => `<th>${header}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${data.map(row => `<tr>${row.map(cell => `<td>${$(cell).text() || cell}</td>`).join('')}</tr>`).join('')}
                </tbody>
            </table>
        </body>
        </html>
    `;
    
    printWindow.document.write(printHTML);
    printWindow.document.close();
    printWindow.print();
}

function addColumnVisibilityControls() {
    // Add column visibility toggle
    const columnVisibilityHTML = `
        <div class="column-visibility-container mb-3">
            <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#columnVisibility">
                <i class="fas fa-columns me-1"></i>Toggle Columns
            </button>
            <div class="collapse mt-2" id="columnVisibility">
                <div class="card card-body">
                    <div class="row" id="column-toggles">
                        <!-- Column toggles will be populated here -->
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#dataTable_wrapper').prepend(columnVisibilityHTML);
    
    // Populate column toggles
    const table = window.dataTable;
    const columnToggles = $('#column-toggles');
    
    table.columns().every(function(index) {
        const column = this;
        const header = $(column.header()).text();
        
        if (header && header.trim() !== '') {
            const toggleHTML = `
                <div class="col-md-3 col-sm-6 mb-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="col-${index}" checked>
                        <label class="form-check-label" for="col-${index}">
                            ${header}
                        </label>
                    </div>
                </div>
            `;
            
            columnToggles.append(toggleHTML);
            
            // Add event listener
            $(`#col-${index}`).on('change', function() {
                column.visible(this.checked);
            });
        }
    });
}

function setupAdvancedFiltering() {
    // Add feature-based filtering
    const featureFiltersHTML = `
        <div class="feature-filters-container mb-3">
            <button type="button" class="btn btn-outline-info btn-sm" data-bs-toggle="collapse" data-bs-target="#featureFilters">
                <i class="fas fa-filter me-1"></i>Feature Filters
            </button>
            <div class="collapse mt-2" id="featureFilters">
                <div class="card card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">Heart Rate Monitor</label>
                            <select class="form-select form-select-sm" id="filter-heart-rate">
                                <option value="">Any</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">GPS</label>
                            <select class="form-select form-select-sm" id="filter-gps">
                                <option value="">Any</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Water Resistance</label>
                            <select class="form-select form-select-sm" id="filter-water-resistance">
                                <option value="">Any</option>
                                <option value="5ATM">5ATM</option>
                                <option value="10ATM">10ATM</option>
                                <option value="50m">50m</option>
                                <option value="100m">100m</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Display Type</label>
                            <select class="form-select form-select-sm" id="filter-display-type">
                                <option value="">Any</option>
                                <option value="AMOLED">AMOLED</option>
                                <option value="LCD">LCD</option>
                                <option value="OLED">OLED</option>
                                <option value="E-ink">E-ink</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-12">
                            <button type="button" id="apply-feature-filters" class="btn btn-primary btn-sm">Apply Filters</button>
                            <button type="button" id="clear-feature-filters" class="btn btn-outline-secondary btn-sm ms-2">Clear</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#dataTable_wrapper').prepend(featureFiltersHTML);
    
    // Add event listeners for feature filters
    $('#apply-feature-filters').on('click', function() {
        applyFeatureFilters();
    });
    
    $('#clear-feature-filters').on('click', function() {
        clearFeatureFilters();
    });
}

function applyFeatureFilters() {
    const table = window.dataTable;
    
    // Get filter values
    const heartRateFilter = $('#filter-heart-rate').val();
    const gpsFilter = $('#filter-gps').val();
    const waterResistanceFilter = $('#filter-water-resistance').val();
    const displayTypeFilter = $('#filter-display-type').val();
    
    // Apply column-specific searches
    if (heartRateFilter) {
        const searchValue = heartRateFilter === 'yes' ? 'Yes' : 'No';
        table.column(10).search(searchValue); // Heart Rate Monitor column
    }
    
    if (gpsFilter) {
        const searchValue = gpsFilter === 'yes' ? 'Yes' : 'No';
        table.column(11).search(searchValue); // GPS column
    }
    
    if (waterResistanceFilter) {
        table.column(9).search(waterResistanceFilter); // Water Resistance column
    }
    
    if (displayTypeFilter) {
        table.column(5).search(displayTypeFilter); // Display Type column
    }
    
    table.draw();
    
    showNotification('Feature filters applied successfully!', 'success');
}

function clearFeatureFilters() {
    const table = window.dataTable;
    
    // Clear all feature filter selections
    $('#filter-heart-rate, #filter-gps, #filter-water-resistance, #filter-display-type').val('');
    
    // Clear column searches
    table.columns().search('').draw();
    
    showNotification('Feature filters cleared!', 'info');
}

function setupResponsiveFeatures() {
    // Add row selection functionality
    $('#dataTable tbody').on('click', 'tr', function() {
        $(this).toggleClass('selected');
        updateSelectionCount();
    });
    
    // Add select all functionality
    const selectAllHTML = `
        <div class="selection-controls mb-2">
            <button type="button" id="select-all" class="btn btn-outline-secondary btn-sm">Select All</button>
            <button type="button" id="deselect-all" class="btn btn-outline-secondary btn-sm ms-2">Deselect All</button>
            <span id="selection-count" class="ms-3 text-muted"></span>
        </div>
    `;
    
    $('#dataTable_wrapper').prepend(selectAllHTML);
    
    $('#select-all').on('click', function() {
        $('#dataTable tbody tr').addClass('selected');
        updateSelectionCount();
    });
    
    $('#deselect-all').on('click', function() {
        $('#dataTable tbody tr').removeClass('selected');
        updateSelectionCount();
    });
    
    // Add keyboard shortcuts
    setupKeyboardShortcuts();
}

function updateSelectionCount() {
    const selectedCount = $('#dataTable tbody tr.selected').length;
    $('#selection-count').text(selectedCount > 0 ? `${selectedCount} rows selected` : '');
}

function setupKeyboardShortcuts() {
    $(document).on('keydown', function(e) {
        // Ctrl+A - Select all
        if (e.ctrlKey && e.key === 'a') {
            e.preventDefault();
            $('#select-all').click();
        }
        
        // Ctrl+D - Deselect all
        if (e.ctrlKey && e.key === 'd') {
            e.preventDefault();
            $('#deselect-all').click();
        }
        
        // Ctrl+E - Export visible
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            $('#export-visible').click();
        }
        
        // Escape - Clear search
        if (e.key === 'Escape') {
            $('#dataTable_filter input').val('').keyup();
        }
    });
}

function initializeTableTooltips() {
    // Initialize tooltips for badges and other elements
    $('[data-bs-toggle="tooltip"]').tooltip('dispose');
    
    // Add tooltips to badges
    $('.badge').each(function() {
        const text = $(this).text();
        $(this).attr('data-bs-toggle', 'tooltip');
        $(this).attr('data-bs-placement', 'top');
        $(this).attr('title', `Feature: ${text}`);
    });
    
    // Initialize new tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
}

function updateTableStatistics() {
    const table = window.dataTable;
    const info = table.page.info();
    
    // Create statistics display
    const statsHTML = `
        <div class="table-statistics mt-3">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-item">
                        <i class="fas fa-list-ul text-primary"></i>
                        <span>Total Products: <strong>${info.recordsTotal}</strong></span>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <i class="fas fa-filter text-success"></i>
                        <span>Filtered: <strong>${info.recordsDisplay}</strong></span>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <i class="fas fa-eye text-info"></i>
                        <span>Visible: <strong>${info.length}</strong></span>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <i class="fas fa-file-alt text-warning"></i>
                        <span>Page: <strong>${info.page + 1} of ${Math.ceil(info.recordsDisplay / info.length)}</strong></span>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing statistics
    $('.table-statistics').remove();
    
    // Add new statistics
    $('#dataTable_wrapper').append(statsHTML);
}

function updateRowNumbers() {
    const table = window.dataTable;
    const info = table.page.info();
    
    // Update row numbers if they exist
    $('#dataTable tbody tr').each(function(index) {
        const rowNumber = info.start + index + 1;
        $(this).find('td:first-child').text(rowNumber);
    });
}

function highlightSearchTerms() {
    const searchTerm = $('#dataTable_filter input').val();
    
    if (searchTerm && searchTerm.length > 0) {
        // Remove previous highlights
        $('#dataTable tbody').removeHighlight();
        
        // Add new highlights
        $('#dataTable tbody').highlight(searchTerm);
    } else {
        $('#dataTable tbody').removeHighlight();
    }
}

function showNotification(message, type = 'info') {
    const notification = $(`
        <div class="alert alert-${type} alert-dismissible fade show position-fixed" 
             style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    $('body').append(notification);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        notification.alert('close');
    }, 3000);
}

// jQuery highlight plugin (simple implementation)
$.fn.highlight = function(text) {
    return this.each(function() {
        const regex = new RegExp(`(${text})`, 'gi');
        $(this).html(function(_, html) {
            return html.replace(regex, '<mark>$1</mark>');
        });
    });
};

$.fn.removeHighlight = function() {
    return this.each(function() {
        $(this).find('mark').contents().unwrap();
    });
};

// Handle window resize
$(window).on('resize', function() {
    if (window.dataTable) {
        window.dataTable.columns.adjust().draw();
    }
});

// Performance optimization - debounce search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounced search
$(document).ready(function() {
    const debouncedSearch = debounce(function() {
        if (window.dataTable) {
            window.dataTable.search(this.value).draw();
        }
    }, 300);
    
    $(document).on('keyup', '#dataTable_filter input', debouncedSearch);
});
