// Analysis page JavaScript functionality

function initializeAnalysisCharts(displayTypeData, strapMaterialData, batteryData, ratingData, priceBins, priceBinEdges) {
    // Display Type Pie Chart
    const displayTypeCtx = document.getElementById('displayTypeChart').getContext('2d');
    const displayTypeChart = new Chart(displayTypeCtx, {
        type: 'pie',
        data: {
            labels: Object.keys(displayTypeData),
            datasets: [{
                data: Object.values(displayTypeData),
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Display Type Distribution',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} products (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Strap Material Pie Chart
    const strapMaterialCtx = document.getElementById('strapMaterialChart').getContext('2d');
    const strapMaterialChart = new Chart(strapMaterialCtx, {
        type: 'pie',
        data: {
            labels: Object.keys(strapMaterialData),
            datasets: [{
                data: Object.values(strapMaterialData),
                backgroundColor: [
                    '#28a745',
                    '#dc3545',
                    '#ffc107',
                    '#17a2b8',
                    '#6f42c1',
                    '#fd7e14'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Strap Material Distribution',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} products (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Battery Life by Brand Bar Chart
    const batteryCtx = document.getElementById('batteryChart').getContext('2d');
    const batteryChart = new Chart(batteryCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(batteryData),
            datasets: [{
                label: 'Average Battery Life (Days)',
                data: Object.values(batteryData),
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                borderRadius: 5,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Average Battery Life by Brand',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed.y;
                            return `${context.label}: ${value} days`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Days',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        color: '#e9ecef'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Brand',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        font: {
                            size: 12
                        },
                        maxRotation: 45,
                        minRotation: 45
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    });

    // Rating Distribution Bar Chart
    const ratingCtx = document.getElementById('ratingChart').getContext('2d');
    const ratingChart = new Chart(ratingCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(ratingData).map(rating => rating + ' Stars'),
            datasets: [{
                label: 'Number of Products',
                data: Object.values(ratingData),
                backgroundColor: 'rgba(255, 193, 7, 0.8)',
                borderColor: 'rgba(255, 193, 7, 1)',
                borderWidth: 2,
                borderRadius: 5,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Product Rating Distribution',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed.y;
                            return `${context.label}: ${value} products`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Products',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        stepSize: 1,
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        color: '#e9ecef'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Rating',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    });

    // Price Distribution Histogram
    const priceHistogramCtx = document.getElementById('priceHistogram').getContext('2d');
    const priceLabels = [];
    for (let i = 0; i < priceBinEdges.length - 1; i++) {
        priceLabels.push(`$${Math.round(priceBinEdges[i])}-$${Math.round(priceBinEdges[i + 1])}`);
    }

    const priceHistogramChart = new Chart(priceHistogramCtx, {
        type: 'bar',
        data: {
            labels: priceLabels,
            datasets: [{
                label: 'Number of Products',
                data: priceBins,
                backgroundColor: 'rgba(40, 167, 69, 0.8)',
                borderColor: 'rgba(40, 167, 69, 1)',
                borderWidth: 2,
                borderRadius: 5,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Price Distribution Histogram',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed.y;
                            return `${context.label}: ${value} products`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Products',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        stepSize: 1,
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        color: '#e9ecef'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Price Range',
                        font: {
                            size: 14,
                            weight: 'bold'
                        }
                    },
                    ticks: {
                        font: {
                            size: 10
                        },
                        maxRotation: 45,
                        minRotation: 45
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    });

    // Add interactive hover effects to insight cards
    document.querySelectorAll('.insight-item').forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
}

// Chart animation controls
function animateCharts() {
    Chart.helpers.each(Chart.instances, function(instance) {
        instance.update('active');
    });
}

// Handle responsive chart resizing
window.addEventListener('resize', function() {
    Chart.helpers.each(Chart.instances, function(instance) {
        instance.resize();
    });
});

// Add scroll animations for cards
document.addEventListener('DOMContentLoaded', function() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
            }
        });
    }, observerOptions);

    // Observe all cards
    document.querySelectorAll('.card').forEach(card => {
        observer.observe(card);
    });
});

// Export chart as image functionality
function exportChart(chartId, filename) {
    const canvas = document.getElementById(chartId);
    const url = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.download = filename;
    link.href = url;
    link.click();
}

// Add export buttons to charts (if needed)
document.addEventListener('DOMContentLoaded', function() {
    const chartContainers = document.querySelectorAll('.card-body canvas');
    
    chartContainers.forEach(canvas => {
        const cardBody = canvas.closest('.card-body');
        const exportBtn = document.createElement('button');
        exportBtn.className = 'btn btn-sm btn-outline-primary position-absolute top-0 end-0 m-2';
        exportBtn.innerHTML = '<i class="fas fa-download"></i>';
        exportBtn.title = 'Export Chart';
        exportBtn.style.zIndex = '10';
        
        exportBtn.addEventListener('click', function() {
            const chartId = canvas.id;
            const filename = `${chartId}_chart.png`;
            exportChart(chartId, filename);
        });
        
        cardBody.style.position = 'relative';
        cardBody.appendChild(exportBtn);
    });
});
