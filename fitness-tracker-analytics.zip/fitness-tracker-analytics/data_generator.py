import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

def generate_fitness_data(num_products=1200):
    """Generate a comprehensive fitness tracker dataset"""
    
    # Set random seed for reproducibility
    np.random.seed(42)
    random.seed(42)
    
    # Define product categories and brands
    brands = {
        'Apple': ['Apple Watch Series 8', 'Apple Watch SE', 'Apple Watch Ultra', 'Apple Watch Series 7', 'Apple Watch Series 6'],
        'Samsung': ['Galaxy Watch5', 'Galaxy Watch4', 'Galaxy Watch Active2', 'Galaxy Watch3', 'Galaxy Fit2'],
        'Fitbit': ['Charge 5', 'Versa 3', 'Sense', 'Inspire 2', 'Charge 4', 'Versa 2', 'Ionic'],
        'Garmin': ['Venu 2', 'Forerunner 945', 'Fenix 7', 'Vivoactive 4', 'Forerunner 245', 'Instinct 2'],
        'Huawei': ['Watch GT 3', 'Watch Fit', 'Band 6', 'Watch GT 2', 'Band 4 Pro'],
        'Xiaomi': ['Mi Band 7', 'Mi Watch', 'Amazfit GTR 3', 'Amazfit GTS 3', 'Mi Band 6'],
        'Polar': ['Vantage V2', 'Grit X', 'Ignite 2', 'Vantage M', 'Unite'],
        'Suunto': ['9 Peak', '7', '5', '3', 'Spartan Ultra'],
        'Fossil': ['Gen 6', 'Sport', 'Carlyle HR', 'Julianna HR', 'Gen 5E'],
        'Amazfit': ['GTR 3 Pro', 'GTS 3', 'T-Rex Pro', 'Bip U Pro', 'GTR 2e']
    }
    
    display_types = ['AMOLED', 'LCD', 'E-ink', 'OLED', 'TFT', 'Monochrome']
    strap_materials = ['Silicone', 'Leather', 'Nylon', 'Metal', 'Fabric', 'Rubber']
    water_resistance_levels = ['IPX4', 'IPX7', 'IPX8', '5ATM', '10ATM', '50m', '100m']
    
    # Generate data
    data = []
    
    for i in range(num_products):
        # Random brand and model
        brand = random.choice(list(brands.keys()))
        base_model = random.choice(brands[brand])
        
        # Add variation to model names
        variations = ['', ' Pro', ' Lite', ' Plus', ' Sport', ' Classic', ' Edition']
        model_name = base_model + random.choice(variations)
        
        # Price based on brand positioning (converted to INR - 1 USD = 86 INR)
        brand_price_ranges = {
            'Apple': (25800, 77400),  # ₹25,800 - ₹77,400 (300-900 USD)
            'Samsung': (17200, 60200),  # ₹17,200 - ₹60,200 (200-700 USD)
            'Fitbit': (6880, 30100),  # ₹6,880 - ₹30,100 (80-350 USD)
            'Garmin': (17200, 86000),  # ₹17,200 - ₹86,000 (200-1000 USD)
            'Huawei': (5160, 34400),  # ₹5,160 - ₹34,400 (60-400 USD)
            'Xiaomi': (2580, 17200),  # ₹2,580 - ₹17,200 (30-200 USD)
            'Polar': (15480, 60200),  # ₹15,480 - ₹60,200 (180-700 USD)
            'Suunto': (25800, 77400),  # ₹25,800 - ₹77,400 (300-900 USD)
            'Fossil': (8600, 34400),  # ₹8,600 - ₹34,400 (100-400 USD)
            'Amazfit': (4300, 25800)  # ₹4,300 - ₹25,800 (50-300 USD)
        }
        
        price_range = brand_price_ranges[brand]
        price = round(random.uniform(price_range[0], price_range[1]), 0)
        
        # Rating influenced by brand reputation
        brand_rating_bias = {
            'Apple': 0.3,
            'Samsung': 0.2,
            'Fitbit': 0.1,
            'Garmin': 0.2,
            'Huawei': 0.0,
            'Xiaomi': -0.1,
            'Polar': 0.1,
            'Suunto': 0.1,
            'Fossil': 0.0,
            'Amazfit': -0.1
        }
        
        base_rating = random.uniform(3.5, 5.0)
        rating = min(5.0, max(1.0, base_rating + brand_rating_bias[brand]))
        rating = round(rating, 1)
        
        # Review count influenced by brand popularity and price
        popularity_factor = {
            'Apple': 5.0,
            'Samsung': 4.0,
            'Fitbit': 3.5,
            'Garmin': 2.5,
            'Huawei': 2.0,
            'Xiaomi': 4.5,
            'Polar': 1.5,
            'Suunto': 1.0,
            'Fossil': 2.0,
            'Amazfit': 3.0
        }
        
        base_reviews = random.randint(10, 2000)
        review_count = int(base_reviews * popularity_factor[brand] * (1 + (5 - rating) * 0.1))
        
        # Battery life influenced by display type and features
        display_type = random.choice(display_types)
        battery_multiplier = {
            'AMOLED': 0.8,
            'LCD': 1.0,
            'E-ink': 2.0,
            'OLED': 0.7,
            'TFT': 1.2,
            'Monochrome': 1.8
        }
        
        base_battery = random.uniform(1, 14)
        battery_life = round(base_battery * battery_multiplier[display_type], 1)
        
        # Features
        heart_rate_monitor = random.choice([True, False]) if price > 50 else False
        gps = random.choice([True, False]) if price > 100 else False
        water_resistance = random.choice(water_resistance_levels)
        sleep_tracking = random.choice([True, False]) if price > 40 else False
        step_counter = True  # Almost all fitness trackers have this
        
        # Additional features based on price tier
        if price > 300:
            ecg = random.choice([True, False])
            blood_oxygen = random.choice([True, False])
            stress_monitoring = random.choice([True, False])
        else:
            ecg = False
            blood_oxygen = False
            stress_monitoring = False
        
        # Weight and dimensions
        weight = round(random.uniform(20, 80), 1)  # grams
        thickness = round(random.uniform(8, 15), 1)  # mm
        
        # Connectivity
        bluetooth = True
        wifi = random.choice([True, False]) if price > 150 else False
        nfc = random.choice([True, False]) if price > 100 else False
        
        # Create product record
        product = {
            'id': i + 1,
            'name': model_name,
            'brand': brand,
            'price': price,
            'rating': rating,
            'review_count': review_count,
            'display_type': display_type,
            'battery_life_days': battery_life,
            'strap_material': random.choice(strap_materials),
            'water_resistance': water_resistance,
            'heart_rate_monitor': heart_rate_monitor,
            'gps': gps,
            'sleep_tracking': sleep_tracking,
            'step_counter': step_counter,
            'ecg': ecg,
            'blood_oxygen': blood_oxygen,
            'stress_monitoring': stress_monitoring,
            'weight_grams': weight,
            'thickness_mm': thickness,
            'bluetooth': bluetooth,
            'wifi': wifi,
            'nfc': nfc,
            'release_year': random.randint(2019, 2024),
            'warranty_years': random.randint(1, 3),
            'color_options': random.randint(2, 8),
            'storage_mb': random.choice([0, 4, 8, 16, 32]) if price > 200 else 0,
            'music_storage': random.choice([True, False]) if price > 200 else False,
            'voice_assistant': random.choice([True, False]) if price > 250 else False,
            'always_on_display': random.choice([True, False]) if price > 150 else False,
            'cellular_connectivity': random.choice([True, False]) if price > 400 else False
        }
        
        data.append(product)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Ensure data directory exists
    import os
    if not os.path.exists('data'):
        os.makedirs('data')
    
    return df

if __name__ == "__main__":
    # Generate and save data
    df = generate_fitness_data()
    df.to_csv('data/fitness_trackers.csv', index=False)
    print(f"Generated {len(df)} fitness tracker products")
    print(f"Brands: {df['brand'].unique()}")
    print(f"Price range: ${df['price'].min():.2f} - ${df['price'].max():.2f}")
    print(f"Rating range: {df['rating'].min()} - {df['rating'].max()}")
