import pandas as pd
import numpy as np
import json
import os
from flask import render_template, jsonify, request, make_response
from app import app

# Load data
def load_data():
    """Load fitness tracker data from CSV file"""
    try:
        df = pd.read_csv('data/fitness_trackers.csv')
        return df
    except FileNotFoundError:
        # Generate data if CSV doesn't exist
        from data_generator import generate_fitness_data
        df = generate_fitness_data()
        df.to_csv('data/fitness_trackers.csv', index=False)
        return df

@app.route('/')
@app.route('/dashboard')
def dashboard():
    """Dashboard page with summary statistics"""
    df = load_data()
    
    # Calculate summary statistics
    total_products = len(df)
    avg_rating = round(df['rating'].mean(), 2)
    avg_price = round(df['price'].mean(), 2)
    avg_battery = round(df['battery_life_days'].mean(), 1)
    
    # Best value products (high rating, low price) - adjusted for INR
    df['value_score'] = df['rating'] / (df['price'] / 10000)
    best_value = df.nlargest(5, 'value_score')[['name', 'brand', 'rating', 'price', 'value_score']].to_dict('records')
    
    # Most reviewed products
    most_reviewed = df.nlargest(5, 'review_count')[['name', 'brand', 'rating', 'review_count']].to_dict('records')
    
    # Top rated products
    top_rated = df.nlargest(5, 'rating')[['name', 'brand', 'rating', 'price']].to_dict('records')
    
    # Brand distribution
    brand_counts = df['brand'].value_counts().head(10).to_dict()
    
    # Price distribution (in INR)
    price_ranges = {
        'Under ₹10,000': len(df[df['price'] < 10000]),
        '₹10,000-₹25,000': len(df[(df['price'] >= 10000) & (df['price'] < 25000)]),
        '₹25,000-₹50,000': len(df[(df['price'] >= 25000) & (df['price'] < 50000)]),
        '₹50,000+': len(df[df['price'] >= 50000])
    }
    
    return render_template('dashboard.html', 
                         total_products=total_products,
                         avg_rating=avg_rating,
                         avg_price=avg_price,
                         avg_battery=avg_battery,
                         best_value=best_value,
                         most_reviewed=most_reviewed,
                         top_rated=top_rated,
                         brand_counts=json.dumps(brand_counts),
                         price_ranges=json.dumps(price_ranges))

@app.route('/analysis')
def analysis():
    """Analysis page with data visualizations"""
    df = load_data()
    
    # Display type distribution
    display_type_counts = df['display_type'].value_counts().to_dict()
    
    # Strap material distribution
    strap_material_counts = df['strap_material'].value_counts().to_dict()
    
    # Average battery life by brand
    battery_by_brand = df.groupby('brand')['battery_life_days'].mean().round(1).to_dict()
    
    # Rating distribution
    rating_distribution = df['rating'].value_counts().sort_index().to_dict()
    
    # Price distribution (histogram bins)
    price_bins = np.histogram(df['price'], bins=20)[0].tolist()
    price_bin_edges = np.histogram(df['price'], bins=20)[1].tolist()
    
    return render_template('analysis.html',
                         display_type_counts=json.dumps(display_type_counts),
                         strap_material_counts=json.dumps(strap_material_counts),
                         battery_by_brand=json.dumps(battery_by_brand),
                         rating_distribution=json.dumps(rating_distribution),
                         price_bins=json.dumps(price_bins),
                         price_bin_edges=json.dumps(price_bin_edges))

@app.route('/recommendations')
def recommendations():
    """Recommendation system page"""
    df = load_data()
    
    # Get filter options
    brands = sorted(df['brand'].unique().tolist())
    min_price = int(df['price'].min())
    max_price = int(df['price'].max())
    min_rating = float(df['rating'].min())
    max_rating = float(df['rating'].max())
    min_battery = int(df['battery_life_days'].min())
    max_battery = int(df['battery_life_days'].max())
    
    # Apply filters if provided
    filtered_df = df.copy()
    
    if request.args.get('brand'):
        filtered_df = filtered_df[filtered_df['brand'] == request.args.get('brand')]
    
    if request.args.get('min_price'):
        filtered_df = filtered_df[filtered_df['price'] >= int(request.args.get('min_price'))]
    
    if request.args.get('max_price'):
        filtered_df = filtered_df[filtered_df['price'] <= int(request.args.get('max_price'))]
    
    if request.args.get('min_rating'):
        filtered_df = filtered_df[filtered_df['rating'] >= float(request.args.get('min_rating'))]
    
    if request.args.get('min_battery'):
        filtered_df = filtered_df[filtered_df['battery_life_days'] >= int(request.args.get('min_battery'))]
    
    # Calculate recommendation score
    if not filtered_df.empty:
        filtered_df['recommendation_score'] = (
            (filtered_df['rating'] * 0.4) +
            ((filtered_df['review_count'] / filtered_df['review_count'].max()) * 0.3) +
            ((1 - (filtered_df['price'] / filtered_df['price'].max())) * 0.2) +
            ((filtered_df['battery_life_days'] / filtered_df['battery_life_days'].max()) * 0.1)
        )
        
        recommendations = filtered_df.nlargest(20, 'recommendation_score')[
            ['name', 'brand', 'rating', 'price', 'battery_life_days', 'display_type', 
             'water_resistance', 'heart_rate_monitor', 'gps', 'recommendation_score']
        ].to_dict('records')
    else:
        recommendations = []
    
    return render_template('recommendations.html',
                         recommendations=recommendations,
                         brands=brands,
                         min_price=min_price,
                         max_price=max_price,
                         min_rating=min_rating,
                         max_rating=max_rating,
                         min_battery=min_battery,
                         max_battery=max_battery,
                         current_filters=request.args)

@app.route('/data_view')
def data_view():
    """Data view page with searchable table"""
    df = load_data()
    
    # Convert DataFrame to records for template
    products = df.to_dict('records')
    
    # Get column names for table headers
    columns = df.columns.tolist()
    
    return render_template('data_view.html', products=products, columns=columns)

@app.route('/export_csv')
def export_csv():
    """Export data as CSV"""
    df = load_data()
    
    # Create CSV response
    response = make_response(df.to_csv(index=False))
    response.headers["Content-Disposition"] = "attachment; filename=fitness_trackers.csv"
    response.headers["Content-Type"] = "text/csv"
    
    return response

@app.route('/export_json')
def export_json():
    """Export data as JSON"""
    df = load_data()
    
    # Create JSON response
    response = make_response(df.to_json(orient='records', indent=2))
    response.headers["Content-Disposition"] = "attachment; filename=fitness_trackers.json"
    response.headers["Content-Type"] = "application/json"
    
    return response

@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')

@app.route('/api/dashboard_data')
def api_dashboard_data():
    """API endpoint for dashboard data"""
    df = load_data()
    
    # Brand distribution for chart
    brand_counts = df['brand'].value_counts().head(10).to_dict()
    
    # Price distribution (in INR)
    price_ranges = {
        'Under ₹10,000': len(df[df['price'] < 10000]),
        '₹10,000-₹25,000': len(df[(df['price'] >= 10000) & (df['price'] < 25000)]),
        '₹25,000-₹50,000': len(df[(df['price'] >= 25000) & (df['price'] < 50000)]),
        '₹50,000+': len(df[df['price'] >= 50000])
    }
    
    return jsonify({
        'brand_counts': brand_counts,
        'price_ranges': price_ranges
    })
